离线用例生成试验。以下是全部冻结输入。仅设计当前分析单元的首次用例及简短业务依据。此次文本试验不生成流程图、不执行真实Run生命周期调用、不使用工具查找更多材料。输出JSON对象：cases数组（各项为behavior-test-case-v1正文）、notes数组（业务推导与待确认事项）。不输出自评分、评审结论或改写过程；不以固定用例数量为目标。

{"analysis_profile": "behavior-test-v2", "analysis_settings": {"scenario": "branch-analysis", "objective": "product-behavior", "mode": "speed"}, "analysis_language": "lua", "unit_id": "U1", "target": "合成打印队列的任务控制与进度通知", "purpose": "负责冻结打印队列的业务分支、操作时序与执行缺口", "source_scope": ["synthetic:queue.lua"], "environment": "CONTRACT.md所列测试台和能力均已提供，未实际执行产品测试"}

## 冻结规则 scene_common_generation
# 场景分析共同规则
当前场景规则与本文件对同一事项规定不同时，以场景规则为准。

仅用于 behavior-test-v2。先读 analysis_scene；按 scene_flow 先保存模块结构化业务流程，再开展当前场景工作。
用户文档和方法论通过 input-read 按需读取，不把全仓清单或所有资料全文写入提示。

## 首次保存前逐例组织（FIRST-CASE-DELIVERY）

每条 test_case 首次写入前，由同一 Analysis worker 按下文“在本轮把内部路径转为可执行场景”的四步完成组织；首条、续接和修复均如此，不另执行一套重复检查。先结合 target、focus、analysis_settings 与单元 purpose 确认本例职责，公开接口目标按真实契约组织。

业务依据随本轮阅读整理到已有 note 或分支覆盖 items/reason，同一业务情形供相关用例复用。记录足以支持结论的业务对象、入口绑定、必要条件与来源、外部后果、触发/观察办法、证据或具体缺口；这是简短推导，不是逐变量字典、固定表格或新增必填字段。引用已保存 note 时用真实 record_id，不另造引用 ID。

有入口、触发和判据依据即可组织并保存当前用例。只有具体疑点才沿相关状态的设置/清除/使用、调用或注册位置及已选工具补读；复用已读证据，不为每例重查共用入口、不预扫描全部依赖。冻结边界或缺失依赖使问题无法回答时，保留已知事实与具体缺口并继续其他候选，不能反复同义搜索、上钻范围或编造业务解释。

一条组织好即保存，不等全单元整理完或额外审核/修正阶段；复杂候选的缺口不推迟已有有效交付。续接、压缩和机械修复复用本 task 冻结规则及已保存依据，仅补当前缺口。语义判断由原 worker 完成，Python 不补写正文、不按符号拒写、不自动重分类或更改准备度。

## 按需使用已选测试工具参考

当前 task 的 test_tool_reference_paths 是用户为本 Run 冻结的测试能力参考，不是被测对象；只用现有 source-search/source-read 按需核实，不对工具做分支、风险或覆盖分析，不全量阅读工具仓库，不执行工具，也不要求用户先写完整操作说明。
当候选用例缺少操作入口、参数、外部观测或清理/恢复方法时，先在这些已选路径中检索入口脚本、参数定义、示例及必要实现；确认真实能力及适用前提后再写操作。没有选择参考或冻结材料仍不足时，保留测试目标和具体缺口，不猜子命令、参数、时限、注入开关或越界找新版本。

复用现有 kind=note 保存共用操作说明：body 使用已有 title、note_id、content、source_evidence 等字段。content 面向执行人员写清执行主机与目录、工具/产品版本及环境前提、带占位符的真实命令模板、参数单位/取值和填法、工具自动完成的行为、外部观测入口、清理/恢复及其依据。未知项明确写未知；命令模板的注释只解释操作，不把内部推演或每例的产品预期塞进共用说明。源码位置使用 repo_id:path:line，记录“已核对冻结资料，未实际执行”。不要求每条用例复制整份共用说明。

用例通过现有记录顶层 relates_to 关联操作 note，例如 [{"unit_id":"U1","record_id":"实际保存的note记录ID"}]；同单元也可用已保存 record_id 字符串。必须使用保存后返回的真实 ID，不把 note_id 当 record_id，不发明 body.note_refs。每条用例仍在 preconditions、steps[*].action/expected、variants 和 cleanup 写明本例具体对象、实际参数值、顺序、外部预期与恢复要求，不能只有“参见工具”。共享模板不能代替具体步骤或预期。

工具若只支持 connect/query，不得为暂停、篡改报文或精确命中认证窗口发明 pause/reset/send-message 能力。主机自动认证写为 connect 后的自动行为及外部观察，不能逐消息伪写成人工操作；内部状态/函数仅作依据，不作为主要判据。缺少控制或观测设施时保留目标，使用 needs_instrumentation；入口或结果依据尚未核实用 unknown，并在 readiness_reason 列明缺口。ready 仅表示设计已有依据，execution_status 仍为 not_run，未接设备不等于缺设施。

## 核实一次操作的实际结果

- **看用户最终收到什么。** 从最外层产品入口追到响应写入或完成回调。异步内部函数返回 0
  可能只表示受理成功；若 RPC 等待完成回调，测试预期采用该回调最终返回给用户的结果。
  日志、返回数组、布尔值和设备名使用实际输出，不由函数名或内部返回值推测。
- **写明配置何时改变。** 操作前使用旧值 A，修改时使用不同的新值 B；逐步核对每一侧的
  当前值。preconditions 是第一步执行前同时成立的状态快照；本次要做的配置改变只写在
  steps.action。前置已完成的连接不再重复创建，清理恢复所有本次改变的配置及创建的对象。
  若先用正常输入验证环境，验证结束后应清理该连接，再开始使用同一名称的异常测试。
- **沿真实终态继续。** 失败后的重试继承实际连接、资源和配置状态。只有真实恢复、重建
  或自动转换才能改变它们；先核对底层守卫、异步资源及回调，再确定第二次操作结果。
  不能把启动前被拒绝等同于事务已启动后失败。
- **让故障可制造。** 核实故障设施、触发条件和恢复方式。没有交付的报文篡改器、内部同步
  开关、内存故障桩等不能假定存在；保存具体触发缺口及源码处理依据。辅助接口用例同样
  需要实际的触发方法、可观察的执行时机和清理方法；“认证正在进行中”等内部状态本身
  只是待制造的条件。方法未确定时，在 summary 保留该分支依据及缺少的执行条件。
- **按路径核实边界。** 使用真实比较式、调用方向和条件编译替代实现；正常完成、超时、
  取消分别核对状态与资源归属。C/C++ 按求值、类型和宏理解，Lua 按返回值、异常和清理理解。
  引用 callee 的实际终态，资源次数按该路径的调用点核实；相似状态分别确认错误分支。
  连续校验按执行顺序逐项追踪：在格式检查处退出的输入不能覆盖后面的长度或校验和错误。
  后续检查需要能通过前面检查的独立输入；尚未准备该输入时，说明具体缺口。
- **沿中间值检查算术边界。** 按实际类型、求值顺序跟踪整数截断、缩放、转换和回绕后的值，
  再检查除数、索引及比较条件。初始值非零不保证运算后非零；用具体输入核对预期，保留
  触发路径的前置条件。静态可构造的局部边界不等于已证明从产品入口可达或已执行。
  每个数值 expected 和 variants 在保存前逐句代入源码验算，在独立 note 按用例及变体标识保存“输入 → 中间值 → 返回值/异常”的短算例。声称“总是小于/等于”时还须检查截断区间的两端，不能用一个例子证明整个范围，也不能用理想数学公式替换实际整数求值。分母、索引等敏感中间值还要检查经过截断后变成零或越界的边界。
- **按展开结果检查宏调用。** 对测试步骤中的宏实参逐项核对读、写和重复求值；被赋值的参数须传可修改左值，写明变量声明、初值及调用后的值。常量、临时结果不能代替被写入的变量；有副作用的实参还须核对求值次数。区分“将变量置为 0 后调用”和“传入常量 0”。
- **区分计时范围。** 产品超时、重连间隔和实验观察窗口各自有起点和结束条件；采用真实
  完成条件，不按参数名称相加推断响应时限。源码已能回答的结果继续读完依据再下结论。

以上核实用于 Analysis 理解和源码依据。共用操作 note 面向执行人员，只保存准备环境、
命令和参数填写方式。产品响应写在对应用例的 expected 中，流程沿用该结果；共用命令的
注释只解释参数用途。内部实现推演仅在结论确实需要时单列证据。

## 从关联逻辑提炼场景，再确定用例粒度

在本轮源码阅读中先说明：谁，在什么业务阶段，执行什么操作或遇到什么事件，需要验证什么行为。
product-behavior 以产品行为为目标；interface-contract 可以公开接口的输入、调用顺序、返回和资源契约为目标。
上下关联的判断、helper 调用与清理步骤是理解场景的依据，不能直接按代码路径拼成一条用例，
也不能按 if/else、函数、流程节点或内部变量的数量决定用例数量。只把内部符号翻成中文仍不是场景提炼。

- **结合注释核实业务含义。** 阅读关键判断附近的注释、函数职责、调用上下文，以及相关状态的设置和清除位置。
  注释解释意图，实现说明成立条件和当前行为，需求/设计/协议或接口契约提供正确预期；相互冲突时分别保留依据和待确认事项。
  没有独立预期依据时标明当前结论仅为源码推导，不能把代码当前行为自动当成正确答案，也不扩大冻结范围。
- **区分条件的作用。** 定义业务情形的条件保留在场景中；操作后自然形成的内部状态用于证明触发关系，
  不写成人工置位步骤；到达目标处理所必需的条件，追查并转为实际准备或触发要求。
  内部保护、辅助分流和清理细节先判断是否揭示独立验证目标；没有则留在依据中。
  含义或必要性未知时保留具体缺口，不能因为它出现在路径上就加入前置，也不能随意删去。
  资源申请失败等内部条件若对应真实故障情形，继续核实外部触发或已有灰盒设施，不因去白盒而丢掉场景。
- **按验证目标拆合。** 一次业务情形自然经过多个关联判断，或跨多个函数/文件，不据此拆例。
  独立故障条件、关键事件交错、业务/接口契约或恢复要求需要分别验证时，保留独立目标并说明拆分理由。
  相同外部结果、错误码或共享 handler 不证明业务等价；不同内部代码路径也不证明业务不等价。
  不因都断链成功而合并普通关闭与关闭交错，也不因 FIN/RST 与标记取值就自动生成全组合。
  同一场景的操作、主要判据和恢复一致的数据变化可放 variants，每个变体保留实际输入与预期。
  这里的顺序指测试人员的实际操作或有业务意义的事件时序，不是内部求值和调用顺序。
- **保留简短推导。** 在已有 note 中关联业务情形、验证目标、必要条件、触发手段、主要判据、源码依据与拆合理由。
  分支场景复用 behavior-coverage-v1 的 items/reason、其他场景复用现有分析 note；不逐个 if 建账，
  不新增记录合同、转换 Agent、全局阶段或 Python 语义门禁。比例和数量不能代替上述判断。

## 短用例示例

示例用于学习写法，实际功能与预期需要当前任务的证据支持。

**正确密钥连接成功**

- 前置：目标要求认证，主机配置匹配密钥，本次连接和设备不存在。
- 操作：主机连接目标，查询连接和设备。
- 预期：连接成功，出现本次连接及连接命令返回的设备。
- 清理：断开本次连接，查询确认连接和设备移除。

**错误密钥被拒绝，修正后恢复**

- 前置：正确密钥已验证能连接并已断开，目标配置保持不变。
- 操作：使用格式合法但不匹配的密钥连接；确认失败后改回正确密钥重新连接。
- 预期：首次被拒绝且没有本次连接和设备；修正后连接和设备出现。
- 清理：断开本次连接，查询确认连接和设备移除。

**在线更新密钥**

- 前置：主机与目标均使用密钥 A，现有连接和设备可用；主机已注册不同的新密钥 B。
- 操作：目标改为 B；主机对现有连接提交 B；查询连接和设备。
- 预期：更新成功，原连接及对应设备仍可查询到。
- 清理：断开本次连接并确认移除，将目标密钥恢复为 A。

**主动关闭过程中收到对端 FIN：场景骨架**

- 目标：验证主动关闭与对端关闭交错时，目标连接按约定结束。
- 必要条件：核实主动关闭标记的来源、有效窗口及前序约束；“在途数据”等只有确为必要时才保留。
- 操作与判据：通过已提供的真实关闭入口及已核实的时序控制/确认手段触发，使用连接查询、协议记录等确认约定的结果；撤销控制措施并恢复环境。
- 依据：内部标记、状态机、函数调用和清理动作单列证据，不逐项改写成操作及主要预期。

本例不提供具体产品命令或注入设施，不能直接标 ready。“同时关闭”或“制造交错”只是条件描述，
不能证明命中目标窗口；尚未实测与根本缺少控制/观测设施分别记录。无崩溃也不证明无内存破坏，
内存安全观察点须有相应依据与真实诊断设施。

## 在本轮把内部路径转为可执行场景

对每个候选按以下四步完成分析与写作，不另开转换回合；已有场景 note/items/reason 复用即可，不新增合同。

1. **映射条件。** 从目标入口追查内部条件的设置、清除和使用，把必要条件对应到执行人员能建立的
   外部准备、输入或事件；操作自然产生的状态只作为触发依据。写清谁、业务阶段、验证目标与恢复要求，
   不按内部判断/回调/清理调用逐项生成步骤。说明内部状态影响哪个业务对象及其后续行为；字段中文名不是业务含义的证据。
   遍历集合时核实对象如何选入、作用范围及未选对象是否受影响，不把“对全部节点调用函数”当成步骤。
   尚不能映射的条件保留具体缺口，不删除真实故障场景，也不把难构造、缺设施当成不可达。
2. **确定刺激和观测。** steps.action 写实际入口/工具及操作（或引用已核实的共用操作 note）；
   steps.expected 写通过该入口的响应、连接/设备查询、I/O、协议记录或有依据的指标能判定的结果。
   每个expected中的每个断言（包括并列、附加及variants预期）均明确观察对象、方法与成功/失败区别；“正常处理”“正确关闭”“无泄漏”不能替代判据。
   观察方法可复用本例步骤或已关联的共用操作，不机械重复文字；external_observations 只放补充检查，允许 []。
   对照证据确认刺激命中本例条件：错误密钥可验证普通认证失败，不能代替非法字段长度、畸形报文或阶段消息缺失；相同拒绝结果不证明触发等价。
   内部回调发生、变量置位、helper 被调用或内部队列状态不作产品黑盒判据，即使中文化也不行；不能用一句外部成功夹带未证实可观察的内部终态或资源释放。
   自动完成的协议交互写为观测，不伪写成人工逐条发送；只有已核实工具提供相应控制时才列为操作。
   协议报文、公开状态字段和同名私有枚举分别核实来源与观测边界，不按词名删除合法消息或公开接口判据。
   清空引用、移除列表项或取消标志不自动证明后台处理停止或资源释放；沿实际消费者、调度或释放契约核实对外后果。
   连接成功、后续可用或再次连接成功不证明本次认证资源已释放；资源断言须有真实观测设施、对象归属、基线及完成条件，否则保留验证缺口，内部清理推演仅作证据。
   对每步反问：不查看私有函数/变量，执行人员能否判定？不能则继续寻找观测或保留未知，不能只删符号。
3. **单列依据，保留真实层级。** source_evidence 和关联 note 保存内部因果与已读源码位置，正文保留
   实际必要的协议字段、报文、抓包和技术参数。product-behavior 优先外部行为；interface-contract
   可直接验证有证据的公开 API 输入、调用顺序、返回、公开状态及资源契约，不将公开函数误删为白盒。
   灰盒允许精确写出内部注入点，但须有现存工具/桩、目标请求、阶段、值/延迟、次数/时间窗和撤销方式，
   由外部业务触发并以外部结果作主要判据；延迟对照真实计时区间及阈值，撤桩后验证恢复。
   私有函数直接调用仅在任务需要且可运行测试桩有证据时保留为开发辅助，不冒充公开 API 或产品入口。
4. **核实准备度后保存。** test_level 表示操作/观测的真实边界，execution_readiness 表示设计是否具备执行条件，不能相互替代。每条正式及辅助用例的 readiness_reason 简述入口、条件构造、必要控制与观察依据或具体缺口，不能只写“可执行”。
   这些依据均已核实可标 ready；只有控制、注入或观察设施需要新增时用 needs_instrumentation；业务含义、入口、触发或预期依据未确认时用 unknown，并同时保留已知设施缺口。源码或工具资料可证明设计具备条件，不要求先连接设备或执行产品测试；未执行仍为 not_run。“可编写测试桩”不是现有设施。
   有业务目标但暂缺设施的设计保留，只有内部推演而无业务情形时保存 note/evidence；不能将困难用例删除、改名为 note 或无依据降级来改善比例。正常业务拒绝不自动成为风险。
   保存后仅在发现具体问题时由本 worker 定向替换受影响记录，保留有效内容与源码依据，不追加全量复读。

### 成对示例：握手未继续，不能以回调代替判据

以下 symbol_* 都是占位符，不指向具体产品。未提供的阈值、命令、报文和关闭方式不得据此补造。

- **反例（内部判据）**：发送合法 symbol_init_request 后保持连接但不发送 symbol_connect_request；
  预期“symbol_timeout_callback 回调，symbol_connected 未置位，调用 symbol_close，symbol_queue 消失或关闭”。
  操作可能是外部刺激，预期却只能靠实现细节判断；把 symbol_* 换成中文仍不解决问题。
- **反例（只去符号）**：同一操作，预期“超时后正常处理、连接正确关闭”。未说明何时、从哪里、对哪个连接
  观察到什么，不能验收；不能凭示例把某个等待秒数或 FIN/RST 当成产品契约。
- **正例（有证据才可 ready）**：已核实协议工具支持发送 symbol_init_request、抑制 symbol_connect_request，
  并观察该会话连接；以已核实的计时起点和配置 symbol_timeout 为准，执行该操作，在证据规定的观察窗口内
  通过该工具确认本次连接已由对端结束，且未建立可用会话；撤销抑制并清理本次连接。
  expected 使用连接/会话的外部结果，回调、标记及队列清理因果仅放 source_evidence。
- **正例（当前只有骨架）**：若只有上述内部源码，而阈值、工具、连接结束的外部表现或会话查询未核实，
  保留“握手未继续时超时结束连接”的候选目标及这些缺口，标 unknown；若明确仅缺新增设施则标
  needs_instrumentation。不能把本示例照抄为 ready，也不把“消失或关闭”当作未经确认的二选一预期。

### 成对示例：认证交互不等于内部终态可观察

- **反例（真实问题表述）**：步骤“主机Connect，目标响应AUTHREQ后AuthSend/AuthReceive”；预期“主机继续认证而非直接建立会话”。步骤2“主机依次Negotiate、Challenge、Reply、Success1、Success2”；预期“认证成功：目标端最终进入SUCCESS2终态并释放本次认证资源，认证完成”。未说明真实控制能力、收发方向和每项观察，不能据此认定可执行黑盒；这些名称本身不是错误，也不是完整协议事实。
- **条件化正例**：若现有主机入口自动完成认证，操作写实际连接动作，按本次会话关联的协议记录观察已核实的交互，并按真实完成响应及已核实的连接/设备查询判定可用。只有现有协议工具支持逐阶段控制/确认时，才列相应报文操作及中途“尚未可用”的检查；不能凭示例添加命令、阶段或时间窗。
- **判据拆分**：SUCCESS2若是线上消息则写实际收发事件；若是公开状态则写查询对象与字段；若仅是私有枚举则移入证据。成功结果不能证明资源释放，具备本次资源归属、基线及结束条件的观测设施才保留资源断言；否则明确该验证缺口。入口/协议依据未核实标unknown，仅缺新增控制/观测设施标needs_instrumentation，不把骨架标ready。

## 保存方式

使用当前工具直接提交 object 作为 body，每条用例保存一份。Coverage关联用例在自身body.summary保存逐gap的缺口、外部条件及相对普通步骤的增量依据（见scene_coverage）；这是现有扩展说明，不新增强制schema字段，全局summary不能代替。正文只展开前置、操作、预期、
清理；命令全文放在共用操作 note，source_evidence 保存已读的 repo_id:path:line 和符号名。

<!-- TEST-CASE-CONTRACT:BEGIN -->
### 用例强制结构：behavior-test-case-v1

以下字段结构是强制 schema，不是可以自行改写的样例格式；示例中的业务输入和预期仅演示写法，
必须替换为当前任务证据支持的内容。`kind=test_case` 的 body 遵循以下规则：

- body 直接为 JSON 对象，`format_version` 必须为 `behavior-test-case-v1`；不提交字符串、代码块或另包一层 test_case/body。
- `steps` 必须为非空数组，每项均为含 `action`、`expected` 的对象；两字段必须为非空且非纯空白的字符串。
  每个动作都有对应的预期结果，不使用字符串动作列表，也不把所有步骤的预期合并到顶层 expected/expected_results。
- `external_observations` 必须为数组。它只保存步骤之外的补充观测，不能代替任何一步的 `expected`；
  已在步骤说明的观测无需重复，无补充时填写 `[]`，不能填写字符串或 null。
- `variants` 可以省略；填写时必须为数组，无变体时使用 `[]`。每个变体均为含 `input`、`expected` 的对象，
  两字段必须为非空且非纯空白的字符串，不使用字符串变体列表。

每次提交前逐条检查本批次所有 test_case 的上述字段、类型和必填值，包括正式与辅助用例及定向替换记录；
只检查数量、比例或 coverage_refs 不等于格式自查。再按当前证据核对每步、每个变体的具体预期，
不能为通过格式校验填入“符合预期”等占位文字；尚不能确定的结论保留 note/unresolved 及证据缺口。

```json
{
  "format_version": "behavior-test-case-v1",
  "case_id": "TC-001",
  "title": "错误密钥连接被拒绝，修正后恢复",
  "purpose": "branch",
  "test_level": "business_blackbox",
  "entry": "共用操作：连接、查询连接和设备、断开连接",
  "preconditions": ["目标使用密钥 A；正确密钥已验证能连接并已断开；主机已注册格式合法但不匹配的密钥 B"],
  "steps": [
    {"action": "使用 B 连接并查询连接和设备", "expected": "连接被拒绝，本次连接和设备不存在"},
    {"action": "保持目标配置，改用 A 重新连接并查询", "expected": "连接成功，查询结果包含本次连接及连接命令返回的设备"}
  ],
  "external_observations": [],
  "cleanup": ["断开恢复后创建的连接，查询确认本次连接和设备移除"],
  "flow_refs": [],
  "coverage_refs": [],
  "risk_refs": [],
  "variants": [],
  "execution_readiness": "ready",
  "readiness_reason": "入口、操作和主要判据已核实",
  "execution_status": "not_run",
  "source_evidence": ["当前任务已核实的 repo_id:path:line"]
}
```

当前 task 声明 `record_contracts.test_case=behavior-test-case-v1` 时，写入工具强校验上述结构。
错误会逐项给出记录及字段路径，本次提交不落盘、不增加 revision，也不丢弃已有有效记录。
由同一 worker 按精确错误修正同一 result_path 的待提交内容，保留已经核实的动作、预期与证据后重写；
写入失败不能继续声明完成。Python 不自动搬移 external_observations、不补造 expected，也不判断预期是否正确、
用例是否充分或可执行，更不据此判 action/Run 失败。未声明该合同的旧任务继续依其冻结规则执行。
<!-- TEST-CASE-CONTRACT:END -->

purpose：普通主干、业务分支、异常和恢复为 `branch`；真实 Coverage 驱动为 `coverage`；
已确认问题的验证为 `risk`。用例无需先建立 Risk。正式风险关联用例；源码证实无法通过
支持的业务入口到达时，记录不可达依据。没有 Coverage 输入就不声称完成覆盖率补测。
参数变体采用现有报告字段，例如 `variants: [{"input": "摘要 sha256，DH 组 ffdhe2048",
"expected": "连接成功，查询可见本次连接和设备"}]`，每项写清实际输入与预期。
共用数据表已有完整输入时，变体直接引用数据编号；保留原始数据，解释其含义时核对实际
字节与解析顺序。查询预期说明要找到的对象及字段，采用查询接口自身的响应结构。

test_level 按实际操作及观测确定：

- `business_blackbox`：产品 CLI、RPC、服务、配置等正常入口，结果由产品外部观察。
- `interface_contract`：有证据的公开 API，检查接口承诺的返回或输出。
- `developer_assisted`：业务灰盒：从产品入口执行，允许在前置、执行中或清理阶段定点注入故障；
  桩点只制造条件，主要预期仍为产品行为。写清注入位置、时机、值/延迟、作用对象和撤销。
- `whitebox_support`：正式步骤操作私有 helper、内部对象、poll 或内部状态，或预期只能依赖私有状态检查，属于辅助内容；外部动作不能把内部判据变为黑盒。

先交付业务场景。Coverage 指向内部 helper 时先沿真实调用链寻找业务触发方式；能由外部操作
或灰盒注入验证时必须优先这样设计。确实只能内部验证时保留白盒辅助，不能冒充主交付。公开 API 与产品入口各自保留真实层级。

## 业务可实施性与 70% 交付目标

先遵循冻结的 analysis_scene.objective：product-behavior 交付产品行为；interface-contract 交付公开接口输入、调用顺序、状态、返回与资源契约。缺少 objective 的旧任务保持其冻结规则，不从源码名称推断或重新分类。风险场景（risk-method-v1）以及显式 interface-contract 目标不设产品黑盒与灰盒 70% 比例目标；执行准备度仍逐条如实填写。

按 task.target、task.focus 和单元 purpose 阅读入口、主干与跨文件流程。主干 owner 负责把其他单元的必要挂接点、输入/输出及状态关系交代清楚；每个 worker 负责自己的真实边界和与主干的关系。没有源码依据的跨单元关系保留 unresolved。产品入口或调用方在冻结范围外时记录已确认的内部/公开接口边界与缺口，不把内部函数包装成产品操作，不猜入口，不越界读取。

仅对冻结规则适用该比例目标的任务，最终独立用例中黑盒与可实施灰盒合计至少 70%；不是代码覆盖率，也不能靠复制成功用例、
改标签、移入附录或将白盒改名 note 凑比例。所有保留的正式与辅助用例均计入分母。

执行表达、灰盒注入与准备度按上文四步核实；比例不代替入口、刺激和外部判据的证据。
needs_instrumentation 保留设计但不计入可实施分子；内部推演与已有证据不能为凑比例丢弃。

公开 C API 的函数验证不自动算业务黑盒；test_level 按实际操作边界选择。私有内部对象/返回
值验证归入 whitebox_support，公开契约验证保留 interface_contract。未分类或执行条件不足保留在分母。
每条 test_case 保留明确的业务或公开接口验证目标，按上文场景粒度确定拆合；避免 test_case_group 隐藏成员数量，
同一场景的数据变体不重复计数。summary 简述比例、白盒必要性和目标范围的重要缺口；即使比例达标也须处理当前冻结场景范围内的关键场景。coverage 仍只围绕适用缺口，不为补齐主干或比例新增基础功能用例。

首轮完成前优先转化有价值的白盒候选：查业务入口、外部故障触发、灰盒注入。确实无法
转化时如实保留辅助用例和原因，不为比例编造业务预期。已有代码证据和内部分析不丢弃。



正式风险责任仅由冻结场景决定；branch/coverage不生成风险账本，不因risk_refs为空补造风险。资料不足记录unresolved。历史缺陷核实当前适用性，示例只参考表达。
先核实需求正确预期与实现当前行为，冲突分别记录。所有用户标题、说明、步骤和预期使用中文；结构化业务流程的内容使用中文，字段名保持英文。
不同验证目标按场景依据组织用例，同一场景的操作、判据及恢复一致的数据变化可以合并 variants。无新增用例的有效结论保存 summary 和流程，不交空文件。

任务提供现成小型 C 执行设施时，在当前 Run 用冻结源码和最小驱动核实算术/宏反例，并在现有 note/evidence 记录命令、输入、实际输出及退出码。驱动和依赖桩须随证据保存；这只是局部代码执行，不能声称产品入口或实际 Coverage 已验证。无现成设施则明确静态推导及缺口。

## 正式风险的保存格式

仅在冻结场景承担正式风险责任时保存 risk；分支与覆盖率场景的产品疑点仍保存为 note/unresolved。

<!-- RISK-CONTRACT:BEGIN -->
当前 task 的 record_contracts.risk=behavior-risk-v2 时，改用 scene_risk.md 的 RISK-CONTRACT-V2 样例与规则。
当前 task 的 `record_contracts.risk=behavior-risk-v1` 时，`kind=risk` 的 body 直接使用以下对象格式。
示例只说明结构；实际触发、结果、观测及排除条件由当前冻结证据决定。

```json
{
  "format_version": "behavior-risk-v1",
  "risk_id": "R-001",
  "title": "请求取消后仍占用连接资源",
  "trigger": "连接已分配，处理期间收到取消请求并进入提前返回路径",
  "system_result": "该路径跳过连接释放，连接仍记为占用",
  "external_observation": "可通过已提供的连接资源指标观察占用未恢复；产品入口触发方式尚待核实",
  "exclusion_condition": "若实际构建中的调用方保证取消后释放该连接，则排除上述泄漏；当前已读范围尚未发现该保证",
  "source_evidence": ["示例仓库:src/request.c:40-58"],
  "linked_test_case_ids": []
}
```

硬性格式规则：

- body 直接是对象，不外套 risk，不用内层 body 包正文，不提交字符串或代码块。
- risk_id、title、trigger、system_result、external_observation、exclusion_condition 是非空字符串。
  未核实的入口、观测设施或排除条件应如实说明证据缺口；格式完整不表示这些事实已证实。
- source_evidence 是非空数组，每项采用 `repo_id:path:line` 或 `repo_id:path:line-line`。
  执行日志、驱动及其他证据保留在独立 evidence/note 中，不把执行日志路径写作源码行号引用。
- linked_test_case_ids 是数组，可以暂空或省略；正式交付的风险用例关联与不可达依据由当前 Analysis worker 按场景核实，不等待额外审核。
- 使用 external_observation、system_result、linked_test_case_ids，不使用 observed、result、test_case_refs。
  flow_refs 放在相关测试用例中，风险通过 linked_test_case_ids 关联用例。
- 正式风险正文不包含 remediation_hint、fix、patch、suggested_patch；本 Run 的交付是分析证据。
- 写入时只检查上述结构；不合格会逐条报错，由同一 worker 在本轮修正后重写。
  检查不判断风险是否真实、影响程度或证据是否足够，不补造字段，不把格式错误判成 Run 失败。

旧 Run 以其 task 和冻结 rubric 为准，不追溯追加本格式要求。
<!-- RISK-CONTRACT:END -->

## 规划交接

若 inputs 包含 planning_handoff，先经 input-read 分页读取。按 origin、record.kind、scope 与原 relates_to 区分全局说明、本单元责任和未解析关系，保留不确定性。交接只帮助定位必要边界，不是已完成分析；对相关证据与 unresolved 在本单元职责内重新核对源码，不能照抄为事实。无需承担明确属于其他单元的职责。


## 冻结规则 scene_flow
# 模块结构化流程先行
risk 场景（method_version=risk-method-v1）按 scene_risk 的工作顺序，可以在完成镜头检查后再保存流程，流程仍是必交付内容。

适用于 behavior-test-v2 全部四场景。先理解所选对象入口、主干步骤、关键判断、状态变化、异常退出与恢复及必要上下游关系，再开展当前专项。
只深入对象及必要依赖；不为先出流程而完整扫描所有风险、分支或无关模块，不增加全局串行阶段或子Agent。

在当前 analysis action 中先保存 kind=flow 的结构化业务流程（risk 场景按 scene_risk 的工作顺序）；专项分析得到新证据后更新同一逻辑 flow_id 并补充用例关联。跨单元的主干由purpose指定的现有worker负责，连接必须有源码依据，不猜补其他单元结论。

恢复 behavior-flow-v1 正文合同：format_version、flow_id、title、description、role、attach_to、nodes、edges、paths、source_evidence。
- nodes：每个节点使用 id、kind、label、description；入口为 kind=entry，其他节点按真实业务动作、判断和结果表达。
- edges：使用 source_step_key、target_step_key、condition，端点引用已有 nodes.id，表达实际走向、回接或结束。
- paths：使用 path_id、title、condition、node_ids、explanation、case_ids；node_ids 按实际执行顺序引用节点。专项用例产出后补充实际 case_ids，不能虚构关联。
- description 为流程说明，text 只能作为补充，不能替代 nodes、edges、paths。不要将逐函数/变量列表当作模块流程。

关键判断用独立节点表达；不同条件走向实际处理或结果节点，汇合时再引用同一后继。若两条路径条件不同但node_ids完全相同，核对是否漏掉判断后的处理差异，不靠改标题表达真假分支。普通顺序连线的condition留空，只有实际守卫或选择条件才填写，不能把“下一步”当作条件分支。调用者不在冻结范围时，区分已证实的函数内行为与待确认的业务调度顺序，不把使用建议写成已验证调用链。

实际证据引用冻结源码，保存在 source_evidence 中供追溯，业务流程页面不展示该字段。文档预期与实现不同时分开说明。
保存前由当前 worker 随本轮分析核对流程语义及节点、连线和路径引用，不等待额外审核。flow 记录的结构校验（字段、id 引用）属于格式契约，不属于语义门禁：不合格时写入被拒绝并逐条返回错误，由同一 worker 在本轮修正；Python 不拆分自由文本、不自动修复、不补造节点、不新增语义门禁。
已有 module-flow-text-v1 记录保留可读；需要补齐时由原 worker 结合冻结源码修正原流程，不能由客户端猜测。流程使用稳定flow_id；修正以准确record_id supersedes，保留旧记录及正确的用例关联，不重做其他单元。
采用本版冻结规则的 worker 在同一 analysis 中为每条 flow 保存 `sequence`（时序交互）与 `call_graph`（函数与变量关系）。先保存已核实的流程，随后随同一次源码阅读补充这些事实；不因等待附加数据而推迟已有流程和用例交付。缺口明确标为 partial/unknown 或有依据的 not_applicable，不为画图扩大目标范围。worker 不编写坐标、SVG、HTML，不生成图任务、不调用绘图脚本；宿主根据同一 flow 记录确定性渲染三种图。

## 分支深度与处理闭环

以下方法参考固定版本的 softaworks/agent-toolkit `mermaid-diagrams`（3027f20f）与 WH-2099/mermaid-skill（982d9035），已适配本产品 JSON 合同；只使用本 Run 冻结的规则，不安装 Mermaid、不联网、不把 Mermaid 代码写入 flow。通用绘图规范负责表达方式，源码和本场景职责决定实际内容。

- 先逐个核对当前入口中会改变业务走向的判断、返回/提前退出、事件分发、错误传播、重试与资源交接，再形成 nodes/edges/paths。不要只沿成功路径阅读，然后把其他事件统一塞进一条边。函数名不是节点粒度标准，也不设固定节点数量。
- 一条已证实的分支须能回答：什么条件触发，随后做了什么，改变了什么状态/资源，对调用方或外部呈现什么结果，在哪里回接、等待、重试或结束。实际存在且决定结果的步骤分别成节点；没有动作的直接返回可以直接连到出口，不能为了形式完整捏造清理或恢复。
- 连线 condition 只表达触发事件或守卫，不能承载整个处理过程。`recv_fin`、`recv_rst`、超时、取消、资源不足等若在源码中有独立处理，分别连到对应处理节点；即使最终共用释放/退出节点，也要保留释放前的差异。正常关闭、预期拒绝、可重试中间态与失效分开说明，error 节点不等于产品缺陷。
- 读到分发器或被调子过程时，在当前对象及必要依赖内追到业务结果。对同一资源说明所有权移交/保留/释放发生在哪里；对异步工作说明受理、等待回调和完成边界。看不到回调或调用者时，在 description 明确已知边界和待确认，不猜跨入口调用顺序。
- 复杂过程拆成具有真实业务边界的 sub，并用 attach_to 指向准确节点；父图仍保留判断、分支去向与出口，子图展开实际处理。不能用“处理异常”一个总括节点、一个异常箭头或省略号隐藏多个不同结果，也不能用虚线替代缺失节点。

示意（假设源码确有以下行为；不代表任何协议实现必然如此）：一次接收先判断结果；收到数据后再检查报文完整性，完整则提交处理，不完整则保留接收状态并等待后续；对端正常关闭先停止接收并完成待处理请求，再释放连接；连接复位先向请求方报告失败，再释放连接；暂时不可读保留连接并退出本次回调等待下一次事件。这里“数据/FIN/RST/暂不可读”是条件，“保留状态/完成请求/报告失败/释放连接”是节点。共享释放节点不抹掉此前不同处理；不同回调也不凭空连成一次连续执行。

### 写入前与写入响应自检

按真实执行顺序先走一遍各 paths，再填写两份引用；同时修改路径时一并更新 node_ids 和 edge_ids，不只在图上加节点。

1. `edge_ids.length == max(node_ids.length - 1, 0)`。第 i 条 edge 的起终点必须分别为 `node_ids[i]` 和 `node_ids[i+1]`，不能混用全图边序号与路径内步号。
2. 循环重复经过同一节点/连线时保留重复项，说明继续/退出条件；不同互斥分支分别建 path，不能首尾拼接为一次执行。
3. 同起终点有多条条件边时明确本路径选择的 edge_id。引用缺失时核实原源码和记录，不用最短路、数组位置或自动连边填空。
4. 检查结果写入响应的 warnings。若提示 paths/edge_ids 的具体错位，在本轮按源码核实并通过原结果写入机制 supersedes 对应 record_id；只修受影响 flow，保留其他有效结果。不能仅因写入成功就忽略 warning，也不能仅为消除 warning 删除分支。证据不足时保留原结论和待确认事项，不启动额外完整分析/自动续接。

这些是 Agent 的分析和自检职责，不新增 Python 语义门禁。写入警告不阻断 action/Run，也不授权宿主替换原路径。

## 业务粒度与跨次可比较性

适用于冻结了本版规则的新 Run。相同模块名不代表输入相同；先遵守当前冻结目标、源码、资料、场景及方法论范围。若 task 提供 flow_stability 输入，按其中的输入指纹理解可比较范围，不能自行扫描历史 Run 寻找旧图。输入相同也不能保证 LLM 自然生成完全相同的结论。

- 节点以一项业务动作、改变后续行为的决策、状态转换、外部终态或恢复动作为单位。普通赋值、helper 调用和局部变量不因实现拆分独立成节点；只有解释业务选择或结果所必需时才展开。可独立说明且有明确业务边界的子过程单列 sub，挂接点使用准确 flow_id/node_id；不能本次按函数、下次任意按业务章节改变粒度。
- 流程展开深度与用例粒度分别确定：nodes/edges/paths 保留已核实的处理差异，用例按冻结生成规则中的业务或公开接口验证目标组织。路径、节点与用例不要求一对一，不能从 paths 自动批量派生用例，也不能为减少用例合并或删除真实流程分支。同一业务用例可关联多条适用路径，关联仍须有真实输入、必要条件和时序依据；不强迫每条路径都有独立 case_id。
- 入口、正常完成、正常拒绝、超时/取消及恢复的区别以证据决定。主干可以有多个，不把第一个数组元素或最长路径默认当主干；确无适用主干时明确说明，不猜造。合法参数变化若操作、判据与恢复一致，可共用流程并在用例保留全部变体，不为每个数据值复制同一张图。
- flow_id、节点 id、path_id 采用与业务入口/角色绑定的稳定名称，不使用随机数、时间、Run 编号、当前遍历序号或标题翻译作为身份。flow_id 可按 `repo_id:relative_path:entry_symbol:operation` 命名；同一证据锚点下的多个操作须有明确区分。已有身份只在同一业务对象与依据仍成立时复用，不能强迫新流程与旧错图一致。

新记录提供以下可选稳定元数据（原 behavior-flow-v1 字段保持不变）：

- `layout_version: "stable-v1"`：声明采用稳定身份与显式路径；缺字段或身份尚未核实时仍保留原流程和缺口，不伪称稳定，不授权宿主补造身份。
- `main_path_ids: []`：Agent 明确选择主干 path_id，可有多条；无适用主干填空数组并在 description 解释。每条正常分支是否属于主干由 Agent 依据业务职责决定。
- `nodes[].semantic_key`：由 Agent 根据已读源码填写“repo/path/入口或符号/可定位的源码锚点 + 业务角色”的身份，例如 `web:src/login.c:login_handler:submit|entry`。source_evidence 保留精确行段；标题、行号单独、相似函数名或数组位置不证明语义身份。锚点改变时核实是真实行为变化还是位置移动并说明，宿主不模糊匹配、不自动归并。
- `edges[].edge_id`：为真实连线显式给出稳定 ID；同起点终点的不同条件必须有不同 edge_id，不能按节点对合并。条件含义由 Agent 核实，ID 不以展示顺序命名。
- `paths[].edge_ids`：按实际执行顺序列出准确 edge_id，与 node_ids 的相邻步对应；循环可重复引用节点和边，保留次数/退出条件说明。平行条件边必须明确选中哪一条，不能由客户端猜测。未知时保留缺口，不从最短路、上下游可达集合生成业务路径。

这些字段帮助机械对应与确定性排序/渲染，不证明业务正确或覆盖充分。缺元数据的旧流程继续可读，不追加语义门禁，也不靠宿主重写成稳定版本。

普通新建 Analysis 不接收 `flow_baseline` 和 `flow_comparison`，不等待 comparison 或 independent_review。显式增量 Analysis 仍按其冻结职责读取 `incremental_parent_records` 等父记录，并由本 worker 核实新增、删除、拆合、条件与连线变化的依据，在已有 note 中区分输入变化、纠正旧遗漏、展示变化或待确认；不自行检索其他 Run。机械 diff 只表示显式身份、字段或拓扑变化，不证明语义等价。源码未变仍允许有证据的纠错，不为稳定外观隐藏变化，不用相似标题或旧基线自动替换本轮结论。历史 comparison/independent_review 任务继续使用原冻结输入合同，不追补新职责。

<!-- FLOW-CONTRACT:BEGIN -->
### 同一流程的三种展示

`nodes/edges/paths` 是业务流程；`sequence` 是参与者间已核实的交互；`call_graph` 是真实函数调用点和关键变量读写。三者共享当前流程、冻结源码和记录修订，但不能互相猜造：不把业务节点当函数，不把节点数组顺序当实际消息顺序，不为布局连通添加调用边。

- `sequence.format_version="sequence-v1"`，包含 `title/status/participants/messages/fragments/notes`。参与者为 `{id,label,description?}`；消息为 `{id,from,to,label,kind,source_evidence?}`，`kind` 使用 `call/return/async/self`，端点引用 participants.id。消息顺序与 source_evidence 由源码证明；同职责 helper 不必各占一个参与者。内部状态改变或清理可用 from=to 的 self，不能捏造外部参与者。
- `fragments` 只声明语义：`{id,kind,label?,operands:[{condition,message_ids:[]}]}`，kind 使用 `alt/opt/loop/par`。alt 的不同 operand 是互斥分支；loop 写明继续/退出条件；par 只在已确认并发关系时使用，不能伪称分支间有确定先后。message_ids 引用本 sequence 已声明的稳定消息 ID，按该分支真实顺序列出；一个消息属于一个 operand，片段中的消息在 messages 中连续排列，不重叠、不嵌套。不支持的复杂局部时序通过 sub flow 分开保存并注明边界。无片段填空数组。无需也不得填写像素坐标、画布大小或路由。
  operands 的声明顺序可以与 messages 中各分支的存放顺序不同；它不表示互斥或并行分支之间的执行先后。同一 operand 内的 message_ids 仍保留该分支已核实的消息顺序；宿主按声明分支分别展示，不能为布局改写原消息事实。
- 每条关键消息引用调用、收包、状态判断或调度发生处。区分报文、处理入口、内部处理与返回；跨层概括须说明。沿每条 path 分别选取 alt 分支，核对共享后继能否到达。对可重复 loop 连走两轮，核对轮界是否重复发送或先消费后接收。重试和重定向标明重新进入的步骤；片段无法表达时拆子流程或在 notes 标明回到哪个消息及其条件。修订消息或分支后重新核对最终版本的受影响路径。
- `call_graph.format_version="call-graph-v1"`，包含 `title/status/root/functions/calls/variables/notes`。functions 是 `{id,kind,label,signature,file,line}`，kind 为 `function/macro/external`；calls 是 `{from,to,file,line,args:[],returns}`；variables 是 `{function,name,reads:[],compute,writes,line}`。file 为当前冻结仓库中的相对源码位置，line 为真实行号；args 逐条说明实参→形参，returns 写返回值接收变量。每条 call 必须有真实调用点，不把内部判断、赋值、返回或未证实的调度当调用。变量按已核对的执行顺序记录读取、计算、写入及重要类型转换；不推测运行时数值。
  `reads` 为字符串数组，`compute`、`writes` 为字符串；多个写入事实在 writes 字符串中逐条说明。旧 Run 依自己的冻结版本解释；未明确字符串限制的旧 writes 数组保留每个项目用于兼容展示。

新任务冻结 `record_contracts.diagram="diagram-contract-v1"` 时，写入成功响应的 `diagram_diagnostics` 按 record_id/record_revision/field/code 指出格式问题。invalid 是字段或引用格式错误；missing/unknown 明确保留未提供或待确认状态；valid_but_unsupported 是宿主展示能力边界，不要求 worker 捏造事实来迎合渲染。原 worker 在当前回合根据精确字段局部修正，使用 supersedes 指向旧 record_id，并写回相同 task/result_path；有效内容和原始修订始终保留。仍未确认的关系以 partial/unknown 和具体缺口交付，不等待 Reviewer/closure，不因提示新增自动续接、替换 worker 或把 Run 判失败。
- 两个对象的 `status` 均由 Agent 声明：`ready`（当前范围事实已提供）、`partial`（已知内容和待确认缺口并存）、`not_applicable`（有证据说明此范围不适用）、`unknown`（尚不能确认）。`notes` 解释边界、动态调用、未知外部实现或不适用原因。就绪不表示已实测；已有有效事实保留，未知关系不能猜画。
- 这些是当前冻结 rubric 的分析交付职责；不新增 Python 写入门禁、不增加 Agent 或完整复核轮次。旧 Run 按旧冻结规则执行，不追补新合同。报告和客户端保留缺字段、未知或无法结构化的原始内容并提示，不能据此判定主分析失败。

#### 字段与引用核对（每条 flow 均执行）

- 两图的 `notes` 均为字符串数组，无备注为 `[]`。参与者、消息、片段的 `id` 非空且各自唯一，名称写 `label`，不能用 `name`；消息 id 不能省略。
- 片段写 `id/kind/operands`，不用 `type/branches`；alt/par 至少两个 operand，opt/loop 恰一个，message_ids 为非空消息 ID 数组。
- 函数 `kind` 不省略；`root/calls[].from/calls[].to/variables[].function` 均引用本图 functions.id，不用 caller/callee/scope 等别名。args/reads 为字符串数组，compute/writes/returns 为字符串，line 为正整数或 null。

完成前由原 worker 逐条回看 main/sub flow 的两份数据，主图不能代替子图；对照各 paths 核实正常、拒绝、异常、重试/清理交互，不只写成功请求/响应。单函数内部变化可用一个参与者的 self，无调用则 calls=[]。未完成用 partial/unknown 并在 notes 说明具体缺口，不以 ready 掩盖省略或因格式不熟声称 not_applicable。写入成功不代表可绘制或完整；本轮发现问题就用原结果修订机制更正准确 record_id，保留有效字段，不由 Python 补关系、不另派图表 Agent。

### flow 记录标准样例（behavior-flow-v1，照此结构填写）

以下为虚构的简单登录行为，只演示字段结构，不能作为真实模块的分析深度模板；实际节点、身份、条件及证据须来自当前任务，并按上文展开分支处理闭环。

```json
{
  "format_version": "behavior-flow-v1",
  "flow_id": "web:src/login.c:login_handler:login",
  "layout_version": "stable-v1",
  "main_path_ids": ["login-success"],
  "title": "用户登录",
  "description": "用户提交凭据，经鉴权后建立会话；失败时按原因返回。",
  "role": "main",
  "attach_to": null,
  "nodes": [
    {"id": "submit", "semantic_key": "web:src/login.c:login_handler:submit|entry", "kind": "entry", "label": "提交用户名和密码", "description": "login_handler 接收请求", "source_evidence": ["web:src/login.c:20"]},
    {"id": "verify", "semantic_key": "web:src/login.c:check_password:compare|decision", "kind": "branch", "label": "校验密码", "description": "check_password 比对哈希"},
    {"id": "rejected", "semantic_key": "web:src/login.c:login_handler:reject_credentials|rejection", "kind": "error", "label": "登录被拒绝", "description": "凭据不匹配，不建立本次会话"},
    {"id": "session", "semantic_key": "web:src/login.c:login_handler:create_session|success", "kind": "exit", "label": "建立会话", "description": "写入 session 表并返回 token"}
  ],
  "edges": [
    {"edge_id": "submit-verify", "source_step_key": "submit", "target_step_key": "verify", "condition": ""},
    {"edge_id": "verify-success", "source_step_key": "verify", "target_step_key": "session", "condition": "密码匹配"},
    {"edge_id": "verify-rejected", "source_step_key": "verify", "target_step_key": "rejected", "condition": "密码不匹配"}
  ],
  "paths": [
    {"path_id": "login-success", "title": "正常登录", "condition": "密码正确", "node_ids": ["submit", "verify", "session"], "edge_ids": ["submit-verify", "verify-success"], "explanation": "凭据匹配后建立本次会话", "case_ids": []},
    {"path_id": "login-rejected", "title": "拒绝错误凭据", "condition": "密码不匹配", "node_ids": ["submit", "verify", "rejected"], "edge_ids": ["submit-verify", "verify-rejected"], "explanation": "拒绝本次登录，不创建会话", "case_ids": []}
  ],
  "source_evidence": ["web:src/login.c:20-88"],
  "sequence": {
    "format_version": "sequence-v1",
    "title": "登录请求与响应",
    "status": "ready",
    "participants": [
      {"id": "client", "label": "客户端", "description": "提交登录请求"},
      {"id": "service", "label": "登录服务", "description": "校验凭据并建立会话"}
    ],
    "messages": [
      {"id": "request", "from": "client", "to": "service", "label": "提交凭据", "kind": "call", "source_evidence": ["web:src/login.c:20"]},
      {"id": "accepted", "from": "service", "to": "client", "label": "返回会话 token", "kind": "return", "source_evidence": ["web:src/login.c:70"]},
      {"id": "denied", "from": "service", "to": "client", "label": "返回凭据不匹配", "kind": "return", "source_evidence": ["web:src/login.c:35"]}
    ],
    "fragments": [{"id": "login-result", "kind": "alt", "label": "凭据校验结果", "operands": [
      {"condition": "密码匹配", "message_ids": ["accepted"]},
      {"condition": "密码不匹配", "message_ids": ["denied"]}
    ]}],
    "notes": ["静态源码交互说明，不代表已执行登录测试"]
  },
  "call_graph": {
    "format_version": "call-graph-v1",
    "title": "登录调用与校验结果",
    "status": "partial",
    "root": "login_handler",
    "functions": [
      {"id": "login_handler", "kind": "function", "label": "login_handler", "signature": "int login_handler(req_t *req)", "file": "src/login.c", "line": 20},
      {"id": "check_password", "kind": "function", "label": "check_password", "signature": "bool check_password(const char *user, const char *pw)", "file": "src/auth.c", "line": 41}
    ],
    "calls": [{"from": "login_handler", "to": "check_password", "file": "src/login.c", "line": 33, "args": ["req->user → user", "req->password → pw"], "returns": "ok"}],
    "variables": [{"function": "login_handler", "name": "ok", "reads": ["req->user", "req->password"], "compute": "check_password(req->user, req->password)", "writes": "ok", "line": 33}],
    "notes": ["这里只展示已读取的登录调用点，后续会话存储实现待确认"]
  }
}
```

硬性规则：
- 标准字段名与样例一致（英文），用户可见说明使用中文；稳定 ID、semantic_key 与源码锚点保留实际标识。示例 ID 只说明结构，实际生成按上述业务身份命名。
- 一条 flow 记录只放一个流程；有多个流程就写多条 flow 记录。
- edges 的 source_step_key、target_step_key 必须写节点 id，不能写 label；paths.node_ids 同样只引用节点 id。
- body 直接是 JSON 对象：不要写成字符串，不要包 ```json 代码块，不要外套 flow 或 flows。业务流程的 nodes/edges/paths 不用 steps、node_id、name、节点、连线、路径 等别名，edges 不用 from/to；注意 sequence.messages 与 call_graph.calls 恰好使用 from/to，不可混用两个层级的端点字段。
- 节点 kind 只能取 entry | main | branch | error | propagation | recovery | exit。
- role 取 main 或 sub：只有 purpose 指定的 owner 单元的主流程写 main，其他流程一律写 sub。
- attach_to 写子流程挂接到主流程的位置，如 {"flow_id": "F-001", "node_id": "verify"}；不确定时写 null。role/attach_to 只用于排版，缺失时按 sub、未挂接处理。
- 写入时会做结构检查（字段名、id 唯一与引用）；不合格时 pangea_result_write 返回逐条错误，请在本轮按错误修正后重写同一结果。
<!-- FLOW-CONTRACT:END -->
当前 Analysis 在本轮修订 sequence 时核对受影响路径的最终消息次序与后继；资料不足保留 partial/unknown 并说明缺口。不另建 sequence_review 记录或等待 closure。历史 sequence_review=sequence-path-review-v1 的 closure 任务继续按其原冻结规则提交路径复核依据，不迁移为新任务的额外义务。


## 冻结规则 scene_branch
# 分支分析：业务行为覆盖（behavior-branch-v1）

用于当前 Run 冻结的分支场景。目标是发现业务条件、配置、状态、操作顺序与结果的差异，并形成可执行用例；不是一条 if 一条用例，不用语法分支数做质量分母。
不开展正式风险扫描，不建立 risk/check 风险账本，不要求 risk_refs，不判断实现“安全”或“存在缺陷”。参数拒绝、协商失败、超时和取消均可作为预期业务行为。需求/设计与实现不一致时分别保留预期来源、当前行为和待确认事项，不把正常拒绝升级成产品风险。

## 在本轮分析内发现覆盖项

先按 scene_flow 保存业务流程；它是可更新的理解草图，不是穷尽候选的边界。然后在同一 analysis 内执行以下工作，不新增 Agent、全局阶段或复核轮次。

1. **从证据提炼业务情形与变化维度。** 先按 scene_common_generation 说明业务阶段、事件/操作与验证目标。结合相关注释、函数职责、调用上下文和状态设置/清除位置，追踪入口输入、可选配置、枚举/能力表、状态读写、事件顺序和外部结果；读取必要的生产者、转换、使用者及直接依赖。区分定义场景的条件、自然形成的内部状态、必要前序条件和实现细节；类型与常量表是线索，不能将全部内部变量机械变成测试维度。分别记录需求/设计允许的行为、源码当前行为及注释冲突，未知条件保留具体缺口。
2. **找影响行为的关系。** 核实条件之间的约束、参数到消费者的传递、前驱状态与持久状态、操作的生效时机、超时/取消/完成的顺序，以及资源创建/使用/清理对再次操作的影响。沿真实调用链追到外部最终响应或冻结边界；异步受理不等于完成。跨单元关系按 purpose 明确的 owner 处理，引用 context 证据，不假设别人已覆盖。
3. **按适用方法推导候选。** 从下表选择能解释实际关系的方法，不要求每个单元凑齐全部方法，也不展开无关目录。

| 方法 | 使用条件与交付依据 |
| --- | --- |
| 等价类与有限选择 | 对产品支持的有限功能选项，每个有业务意义的合法值至少有用例/变体或明确不适用依据。整数、字符串、数量等大域按真实行为分区；机器类型有限不等于逐值穷举。非法、缺省、未配置等只有在证据支持相应行为时纳入。 |
| 边界值 | 由实际比较式、类型、转换及调用方限制推导边界，覆盖边界两侧与端点；先通过前面的校验，才能触发后面的边界。 |
| 决策表与受约束组合 | 只组合共同定义业务情形或影响验证目标的条件，列有效规则与结果并核实不可达组合；分析表不自动成为用例清单。单项取值覆盖不代替有业务意义的组合覆盖。小而有实际意义的有效组合可全列；较大时说明代表组合及未覆盖部分，pairwise 不能替代已确认的高阶业务规则。不能按内部枚举、标记、判空和代码路径机械生成笛卡尔积。 |
| 状态转换 | 由真实入口、前驱状态、守卫、动作和后继状态形成覆盖项；相同调用在不同状态下的结果分别核实。 |
| 场景序列 | 对重试、重新配置、取消、完成、清理及再次操作，保留影响结果的历史和顺序。按已发现的状态/数据依赖选择有限序列，不声称穷举无限历史或所有并发交错。 |

4. **核实归类与拆合。** 对“两个输入等价”“此条件已覆盖”“恢复后可再次执行”等假设，尝试改变相关取值、前驱状态或事件顺序，核实是否形成独立故障条件、关键交错、契约或恢复要求。反例用于检查测试归类，不用于产品风险判定。共享函数、相同流程节点或错误码不证明业务等价；不同内部路径也不证明业务不等价。普通断链与关闭交错不能仅因结果相同合并，一次业务情形经过多个判断也不因此拆例。缺证据保留具体未知，不自造支持能力、CLI 或注入设施。
5. **按验证目标落实候选。** 每条 test_case 保留明确业务验证目标；需要分别验证的业务情形、关键事件时序、契约或恢复要求独立成例并说明理由，不由代码路径决定数量。同一场景的实际操作、判据和恢复一致的数据变化可放 variants，每项保留实际输入与预期并独立执行及清理。内部判断、helper 调用和求值顺序不逐项转为测试步骤。可为变体提供稳定 variant_id（如 V-01），供覆盖项准确引用；旧变体没有该字段时不得靠数组序号猜身份。purpose 通常为 branch。execution_readiness 与缺口按 scene_common_generation 填写，不因缺设施删掉重要行为。
6. **反向查漏。** 从已识别的业务维度、有效规则、状态与顺序回查用例/变体；再从用例回查实际触发条件和依据。补齐已知遗漏，更新同一逻辑流程与覆盖 note；不能用“已有成功/失败两条”证明所有配置和状态均已设计。

需求与设计提供正确预期，示例只参考操作和环境，历史缺陷与用户方法论补充边界/顺序经验并核实当前适用性。真实 Coverage 仅辅助排序及显式关联，本场景不承担全量代码 Coverage 补测。

## 业务覆盖记录：已有 kind=note，不新增写入门禁

每个分析单元维护一份 kind=note，body 约定 format_version=behavior-coverage-v1。它是 Agent 的分析记录与报告展示约定，不是 record_contracts，也不是 Python 对完整性、正确性或完成状态的判断。格式异常、旧格式、缺项保留原文和提示；由原 worker 在当前 action 核实，不拒写、不自动补造内容，不等待审核阶段。

一项代表一个有业务意义的条件/配置/状态/顺序及预期，不按函数、语句或所有内部变量制造清单。item_id 在本单元内稳定，case_refs 指向本单元的实际用例；跨单元关系在 scope/reason 中明确 owner 和证据。scope、combination_strategy、operation、expected_behavior、reason 为字符串；conditions、constraints、source_evidence、unresolved_dependencies 为字符串数组；items 与 case_refs 为对象数组。可选 flow_refs 引用实际流程/路径，不要求猜造。
复用 items 的 operation/conditions/constraints/expected_behavior/source_evidence 说明场景依据，在 reason 简述验证目标、拆合理由及触发/判据依据；必要的共用操作和未知事项引用已有 note。无需新增必填字段或平行账本。覆盖项、流程路径和用例不要求一对一，多项关联同一用例时须核实其真实输入确实适用，不能凭共享函数或行号关联。

- designed：已有对应设计，case_refs 指向真实 case_id；有 variant_id 时精确引用。仅表示已设计，不表示可执行、已执行、通过或实测代码覆盖。
- missing：已确认重要业务行为与预期，但尚未生成对应设计；reason 写缺少什么。
- unresolved：行为、约束、预期或依赖尚不能核实；保留已知证据和所缺信息。
- not_applicable：有明确范围/约束依据证明该项不适用；不能把未读、未实现注入或预算不足当作不适用。

以下是假设源码示例，不能照搬功能或预期：

```json
{
  "format_version": "behavior-coverage-v1",
  "unit_id": "当前真实 unit_id",
  "scope": "本单元负责创建任务；持久化接口为直接参考，执行调度由另一明确 owner 负责",
  "combination_strategy": "支持策略逐项设计；数量按有效边界分区；只组合共同影响提交结果的条件，不声称全组合",
  "unresolved_dependencies": ["远端调度完成通知的冻结契约未提供"],
  "items": [
    {
      "item_id": "B-01",
      "operation": "提交任务",
      "conditions": ["任务不存在", "使用受支持策略 A", "数量为允许上限"],
      "constraints": ["输入先通过格式校验"],
      "expected_behavior": "提交被受理，查询可见本次任务；不将受理等同于执行完成",
      "source_evidence": ["示例仓库:src/task.c:20-48"],
      "case_refs": [{"case_id": "TC-001", "variant_id": "V-01"}],
      "status": "designed",
      "reason": "由创建入口与数量守卫推导，变体保留策略及数量"
    }
  ]
}
```

summary 说明已识别项的去向、组合/序列取舍及未知范围；计数用于导航，不是质量分数。不得宣称“找到所有未知遗漏”“100%业务覆盖”或把 variants 数量当作实测分支覆盖率。时间不足保留 missing/unresolved 及已有有效用例，不为清空缺口伪造设计。定向修正只更新受影响记录，保留稳定 item_id 和真实用例引用。


## 冻结规则 lua_business_semantics
# Lua 业务语义取证

仅补充当前场景的语言取证方法；职责、用例组织和准备度遵循本任务冻结的共同生成与场景规则。以下线索按当前候选的具体疑点使用，不要求逐项扫描。

- **入口支持性。** module 返回 table、导出函数或注册 handler 只说明实现可调用。核实适用的消息或服务绑定、参数来源及受支持调用契约，区分内部回调、测试 mock 和生产入口。已确认的公开 Lua API 可直接测试，不必强找 CLI；可 `require` 不证明测试人员拥有产品操作入口。
- **状态的业务作用。** 对影响当前场景的 table 字段、闭包 upvalue、缓存和注册表，结合设置、清除及后续读取位置解释所属业务对象，以及它改变的响应、功能或下一次操作。自然形成的状态不改写成人工置位；按 `:` 的 self 绑定、真假值、多返回值及实际元方法核实条件，不能套用 C 的返回值约定。
- **批量对象范围。** 核实集合成员来源、筛选条件和逐对象结果，不从变量名或一次遍历推断全系统对象；`pairs` 不保证处理顺序。仅保留影响验证目标的对象差异，不把每次内部调用拆成一个测试步骤。
- **停止与释放边界。** 普通 table 字段置 `nil` 只移除该引用，触发元方法时另核实其副作用；不能由此认定其他持有者、定时调度或已运行协程已结束。区分取消后续调度、停止当前处理和释放资源；GC 不能单独证明释放时机或内存回落。
- **受理与完成。** 区分异步启动返回、协程或消息完成及最终 RPC 响应。`pcall` 成功只表示调用未抛出错误，还需解释被调函数的业务返回；捕获异常不自动撤销已发生的副作用。结合实际完成契约说明失败后的状态与恢复。

复用已读证据，只为影响当前触发或判定的缺口补读冻结范围内的绑定、状态消费者或直接依赖。已能说明业务条件和结果时停止扩读，不逐字段全仓追踪。源码证明当前行为，正确预期另核对需求、设计或公开契约；不足时保留具体缺口，不猜操作、设施、时限或外部结果。


## 冻结业务契约 CONTRACT.md
# 合成打印队列：冻结接口与测试环境

这是从零编写的教学夹具，不含任何实际用户业务、用例或源码。C 与 Lua 实现具有相同业务契约，分别交给模型，不把另一语言或 `oracle.json` 作为输入。

## 分析任务

目标为打印任务的取消、进度订阅和失败处理，场景为分支分析，目标类型为 product-behavior。分析范围仅为本目录中选定的一份源码及本文。交付该范围有意义的用例和具体证据缺口，未提供实际 Coverage 数据。源码当前行为与本文冲突时分别说明，不假定实现就是正确预期。

## 已有环境

测试台已提供 `queue-demo`：C 或 Lua 版本均按参数顺序在同一个新进程执行多条命令，每条命令作为一个完整参数传入。进程间队列独立。命令中的整数均使用十进制。本夹具允许任务编号 1–4、组名为一个 ASCII 字母、页数 1–3；超出此域不是本轮分析目标。

例如 `queue-demo "add 1 A 2" "query 1" "step" "query 1"`。实际可执行文件路径由测试台配置提供，不能从这里推测产品命令。

`step` 是测试台已有的单步调度能力；一个命令完成一次完整调度，每个未结束任务最多打印一页。测试期间没有后台自动调度，不使用睡眠或假想毫秒窗口。没有提供内存写入、直接调用实现函数或注入任意设备返回值的能力。

## 支持的命令和独立业务要求

| 命令 | 要求与公开响应 |
| --- | --- |
| `add ID GROUP PAGES` | 创建不存在的任务，输出 `CREATED`；任务为 queued，printed=0，自动启用进度订阅。 |
| `query ID` | 输出 `STATE printed=N events=M`。STATE 为 queued/running/done/cancelled/failed；printed 是本任务实际已打印页数；events 是本次订阅累计收到的进度通知数。 |
| `step` | 输出 `ADVANCED`。正常任务打印一页并发送一次进度通知（有订阅时）；最后一页完成后状态 done。 |
| `unwatch ID` | 输出 `UNWATCHED`，仅停止该任务后续进度通知，保留已有通知计数；任务仍应继续打印，可用 query 查看结果。 |
| `cancel GROUP` | 对该组 queued/running 任务受理取消，输出 `ACCEPTED N`；尚不代表任务已取消。下一次 step 将这些任务置为 cancelled，且不再增加打印页数。其他组、已结束任务不受影响。 |
| `fail-next ID` | 已有测试台故障注入：使指定任务下一次实际打印尝试失败，输出 `ARMED`；该尝试不增加打印页数或进度通知，状态 failed。若任务先被取消，不能据此声称发生过打印失败。 |
| `reset` | 清除本进程全部任务和注入设置，输出 `RESET`。测试结束可 reset，或退出此隔离进程。 |

`query` 的状态、页数及通知计数是支持的外部观察；实现中的取消标记、订阅句柄或内部返回值不是该查询的额外字段。

## 尚未提供的能力与资料

驱动可能主动报告“介质脱落”，业务要求是相关未结束任务转为 failed，保留已打印页数。但测试台没有介质脱落注入或真实设备操作能力。不能把 `fail-next` 等同于驱动主动上报。

源码还包含一个维护入口，未提供其调用方、对外绑定、允许模式或业务要求。函数被链接/模块导出只证明代码可见。本轮不能越界寻找缺失资料，也不要求凭名称猜测其业务用途。


## 冻结源码 synthetic:queue.lua（左侧为行号）
1: local M = {}
2: local jobs = {}
3: 
4: local function active(job)
5:     return job and (job.state == "queued" or job.state == "running")
6: end
7: 
8: -- Driver callback, not bound to a supported test command.
9: function M.printer_media_lost(id)
10:     if active(jobs[id]) then jobs[id].state = "failed" end
11: end
12: 
13: -- Caller, binding and supported modes are outside the frozen material.
14: function M.printer_maintenance(mode)
15:     if mode == 7 then
16:         for _, job in pairs(jobs) do job.watching = nil end
17:     end
18: end
19: 
20: local function advance()
21:     for id = 1, 4 do
22:         local job = jobs[id]
23:         if active(job) then
24:             if job.cancel_requested then
25:                 job.state = "cancelled"
26:                 job.watching = nil
27:                 job.fail_next = false
28:             else
29:                 job.state = "running"
30:                 if job.fail_next then
31:                     job.fail_next = false
32:                     job.state = "failed"
33:                 else
34:                     job.printed = job.printed + 1
35:                     if job.watching then job.events = job.events + 1 end
36:                     if job.printed == job.pages then job.state = "done" end
37:                 end
38:             end
39:         end
40:     end
41: end
42: 
43: local function request(command)
44:     local id, group, pages = command:match("^add (%d+) (%a) (%d+)$")
45:     if id then
46:         id, pages = tonumber(id), tonumber(pages)
47:         if id >= 1 and id <= 4 and pages >= 1 and pages <= 3 and not jobs[id] then
48:             jobs[id] = {pages=pages, printed=0, events=0, watching={}, group=group, state="queued"}
49:             return "CREATED"
50:         end
51:     end
52:     id = command:match("^query (%d+)$")
53:     if id and jobs[tonumber(id)] then
54:         local job = jobs[tonumber(id)]
55:         return string.format("%s printed=%d events=%d", job.state, job.printed, job.events)
56:     end
57:     id = command:match("^unwatch (%d+)$")
58:     if id and jobs[tonumber(id)] then
59:         jobs[tonumber(id)].watching = nil
60:         return "UNWATCHED"
61:     end
62:     group = command:match("^cancel (%a)$")
63:     if group then
64:         local selected = 0
65:         for _, job in pairs(jobs) do
66:             if active(job) and job.group == group then
67:                 job.cancel_requested = true
68:                 selected = selected + 1
69:             end
70:         end
71:         return "ACCEPTED " .. selected
72:     end
73:     id = command:match("^fail%-next (%d+)$")
74:     if id and jobs[tonumber(id)] then
75:         jobs[tonumber(id)].fail_next = true
76:         return "ARMED"
77:     end
78:     if command == "step" then advance(); return "ADVANCED" end
79:     if command == "reset" then jobs = {}; return "RESET" end
80:     return "INVALID"
81: end
82: 
83: -- The simulation host exposes only the documented request commands.
84: for _, command in ipairs(arg or {}) do print(request(command)) end
85: return M
