"""Lightweight source inventory."""
