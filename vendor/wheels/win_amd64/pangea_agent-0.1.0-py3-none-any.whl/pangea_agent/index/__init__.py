"""Evidence indexing utilities."""
