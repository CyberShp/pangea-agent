"""Registered source repository access."""
